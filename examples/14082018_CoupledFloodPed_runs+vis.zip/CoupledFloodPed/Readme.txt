-------------MS21May2018----------------------
- The flood model moved to the version 1.5 of FLAME-GPU and runs on CUDA 9.1
- The model runs on FLAME-GPU for two academic test cases (the results in iteration folder)
- The initial condition of the test case which constitutes topographic features has been preserved as 0.xml in iterations folder


------- NEXT upload: adaptive TIMESTEP,  date: unknown -------- 
